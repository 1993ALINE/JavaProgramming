import java.util.ArrayList;

public class Arraylist {
    public static void main(String[] args) {
        String names[] = new String[4];
        names[0] = "Aline";
        names[1] = "Hridoy";
        names[3] = "Sanim";
        names[1] = "Xihan";
        for (int i = 0; i < names.length; i++)
           System.out.printf("%s\n", names[i]);

        ArrayList<String> name = new ArrayList<>();
        name.add("Aline");
        name.add("Hridoy");
        name.add("Sanim");
        name.remove(0);
        name.set(0, "Rafi");
        name.add("Rimon");
        for (int i = 0; i < name.size(); i++)
            System.out.printf("%s\n", name.get(i));
    }
}
